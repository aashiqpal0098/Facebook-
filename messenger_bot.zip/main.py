import os
import requests
from flask import Flask, request

app = Flask(__name__)

# Tokens yahan daalo ya hosting ke Environment Variables mein set karo
PAGE_ACCESS_TOKEN = os.environ.get("PAGE_ACCESS_TOKEN", "YAHAN_PAGE_ACCESS_TOKEN")
VERIFY_TOKEN = os.environ.get("VERIFY_TOKEN", "mera_verify_token_123")

GRAPH_URL = "https://graph.facebook.com/v19.0/me/messages"


def send_message(psid, text):
    payload = {
        "recipient": {"id": psid},
        "message": {"text": text},
        "messaging_type": "RESPONSE",
    }
    r = requests.post(GRAPH_URL, params={"access_token": PAGE_ACCESS_TOKEN}, json=payload, timeout=10)
    if r.status_code != 200:
        print("Send error:", r.text)


def get_reply(text):
    t = text.lower().strip()
    if t in ("hi", "hello", "hey", "hy"):
        return "Hello! Main ek bot hu. Aapki kya madad kar sakta hu?"
    if "help" in t:
        return "Aap apna sawal likho, main jawab dunga."
    if "bye" in t:
        return "Bye! Phir milte hain."
    return "Aapne kaha: " + text


@app.route("/", methods=["GET"])
def home():
    return "Bot is running", 200


# Facebook webhook verification
@app.route("/webhook", methods=["GET"])
def verify():
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")
    if mode == "subscribe" and token == VERIFY_TOKEN:
        return challenge, 200
    return "Verification failed", 403


# Incoming messages
@app.route("/webhook", methods=["POST"])
def webhook():
    data = request.get_json(silent=True) or {}
    if data.get("object") == "page":
        for entry in data.get("entry", []):
            for event in entry.get("messaging", []):
                psid = event.get("sender", {}).get("id")
                msg = event.get("message")
                if psid and msg and not msg.get("is_echo"):
                    text = msg.get("text")
                    if text:
                        send_message(psid, get_reply(text))
                    else:
                        send_message(psid, "Abhi main sirf text samajhta hu.")
    return "OK", 200


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
