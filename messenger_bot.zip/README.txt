FACEBOOK MESSENGER BOT - SETUP

FILES
- main.py            : bot ka code
- requirements.txt   : libraries (flask, requests, gunicorn)
- Procfile           : start command (Render/Railway ke liye)
- render.yaml        : Render auto-deploy config
- runtime.txt        : Python version
- .env.example       : tokens ka example

TOKENS
1. VERIFY_TOKEN: koi bhi password khud likho (same Facebook webhook mein daalna)
2. PAGE_ACCESS_TOKEN: developers.facebook.com > App > Messenger > Settings > Generate Token

DEPLOY (Bot-Hosting)
1. Upload ZIP karo
2. Environment Variables mein dono tokens daalo
3. Start command: python main.py

DEPLOY (Render)
1. ZIP ko GitHub repo mein daalo
2. Render > New Web Service > repo select
3. Start command: gunicorn main:app --bind 0.0.0.0:$PORT
4. Environment mein dono tokens daalo

WEBHOOK SETUP
1. Meta App > Messenger > Webhooks > Add Callback URL
2. Callback URL: https://TUMHARA-URL/webhook
3. Verify Token: wahi jo VERIFY_TOKEN hai
4. Subscribe karo: messages, messaging_postbacks
5. Page ko app se connect karo

TEST
Page ko Messenger par "hi" bhejo, bot reply dega.
(App Development mode mein sirf admin/tester ko reply dega.)
